﻿using MedicineShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MedicineShop.Controllers
{
    public class MedicineController : Controller
    {
        private MainCaseStudyEntities db = new MainCaseStudyEntities();
        // GET: Medicine
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(User m)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    // Validate user credentials using the database
                    var user = db.Users.FirstOrDefault(u => u.Email == m.Email && u.Password == m.Password && u.Role == m.Role);

                    if (user != null)
                    {
                        if (user.Role == "Admin")
                        {
                            return RedirectToAction("AdminDashboard", "Medicine");
                        }
                        else if (user.Role == "User")
                        {
                            return RedirectToAction("USerDashboard", "Home");
                        }
                    }

                    //ViewBag.Message = "Invalid login attempt";
                    Response.Write("Invalid login attempt");
                    return View();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            return View(m);
        }


        [HttpGet]
        
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(User profile)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (MainCaseStudyEntities db = new MainCaseStudyEntities())
                    {
                        var checkUser = db.Users.Where(x => x.UserName == profile.UserName).FirstOrDefault();
                        if (checkUser == null)
                        {
                            // Add new user to the database
                            db.Users.Add(profile);
                            db.SaveChanges();
                            return RedirectToAction("Login");
                        }
                        else
                        {
                            ViewBag.ErrorMessage = "User already exists";
                            return View();
                        }
                    }
                }
               
            }
            catch(Exception ex)
            {
                Response.Write(ex.Message);
            }
            return View(profile);
        }

        public ActionResult AdminDashboard()
        {
            return View();
        }
    }
}