﻿using MedicineShop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MedicineShop.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult UserDashboard()
        {
            return View();
        }
        [HttpGet]
        public ActionResult ReadData()
        {
            try
            {
                using (var context = new MainCaseStudyEntities())
                {
                    var Data = context.Medicines.ToList();
                    return View(Data);
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            return View();
        }
    }
}