﻿using MedicineShop.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace MedicineShop.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Medicine studentsData)
        {
            try
            {
                //Connect to Linq to entities
                using (var context = new MainCaseStudyEntities())
                {
                    //add data to particular table
                    context.Medicines.Add(studentsData);
                    int resultValue = context.SaveChanges();

                    if (resultValue > 0)
                    {
                        Response.Write("Medicine added Succesfully");
                    }
                    else
                    {
                        Response.Write("Medicine not inserted");
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            return View();
        }

        [HttpGet]
        public ActionResult ReadData()
        {
            try
            {
                using (var context = new MainCaseStudyEntities())
                {
                    var Data = context.Medicines.ToList();
                    return View(Data);
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            return View();
        }

        public ActionResult Delete(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                using (var context = new MainCaseStudyEntities())
                {
                    Medicine studentsData = context.Medicines.Find(id);
                    if (studentsData == null)
                    {
                        return HttpNotFound();
                    }
                    return View(studentsData);
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            return View();

        }

        // POST: StudentsDatas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id)
        {
            try
            {
                using (var context = new MainCaseStudyEntities())
                {
                    Medicine studentsData = context.Medicines.Find(id);
                    context.Medicines.Remove(studentsData);
                    context.SaveChanges();
                    return RedirectToAction("ReadData");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            return View();
        }

        [HttpGet]
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                using (var context = new MainCaseStudyEntities())
                {
                    Medicine studentsData = context.Medicines.Find(id);
                    if (studentsData == null)
                    {
                        return HttpNotFound();
                    }
                    return View(studentsData);
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MId,MedicineName,Manufacturer,ManufactureDate,ExpiryDate,DosageForm,MDescription,Price,ImagePath,Strength")] Medicine studentsData)
        {
            try
            {
                using (var context = new MainCaseStudyEntities())
                {
                    if (ModelState.IsValid)
                    {
                        context.Entry(studentsData).State = EntityState.Modified;
                        context.SaveChanges();
                        return RedirectToAction("ReadData");
                    }
                    return View(studentsData);
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            return View();
        }

        public ActionResult Details(int? id)
        {
            try
            {
                using (var context = new MainCaseStudyEntities())
                {
                    if (id == null)
                    {
                        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                    }
                    Medicine aspEmployee = context.Medicines.Find(id);
                    if (aspEmployee == null)
                    {
                        return HttpNotFound();
                    }
                    return View(aspEmployee);
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            return View();

        }
    }
}